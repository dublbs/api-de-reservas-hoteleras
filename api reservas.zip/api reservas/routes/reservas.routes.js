const express = require('express');
const router = express.Router();

const { 
  getAllReservas, 
  getReservaById, 
  createReserva,
  updateReserva,
  deleteReserva 
} = require('../controllers/reservas.controller');

/**
 * @swagger
 * tags:
 * name: Reservas
 * description: Endpoints para la gestión de reservas
 */

/**
 * @swagger
 * components:
 * schemas:
 * Reserva:
 * type: object
 * properties:
 * id:
 * type: string
 * hotel:
 * type: string
 * fecha_inicio:
 * type: string
 * fecha_fin:
 * type: string
 * tipo_habitacion:
 * type: string
 * num_huespedes:
 * type: number
 * estado:
 * type: string
 * ReservaInput:
 * type: object
 * properties:
 * hotel:
 * type: string
 * fecha_inicio:
 * type: string
 * fecha_fin:
 * type: string
 * tipo_habitacion:
 * type: string
 * num_huespedes:
 * type: number
 * estado:
 * type: string
 */

// --- GET (Todas) ---
/**
 * @swagger
 * /:
 * get:
 * summary: Obtiene todas las reservas (con filtros)
 * description: Retorna una lista de todas las reservas.
 * tags: [Reservas]
 * parameters:
 * - in: query
 * name: hotel
 * schema:
 * type: string
 * description: Filtra por nombre del hotel.
 * responses:
 * '200':
 * description: Una lista de reservas.
 * content:
 * application/json:
 * schema:
 * type: array
 * items:
 * $ref: '#/components/schemas/Reserva'
 */
router.get('/', getAllReservas);

// --- POST (Crear) ---
/**
 * @swagger
 * /:
 * post:
 * summary: Crea una nueva reserva
 * description: Añade una nueva reserva a la base de datos.
 * tags: [Reservas]
 * requestBody:
 * required: true
 * description: Datos de la nueva reserva.
 * content:
 * application/json:
 * schema:
 * $ref: '#/components/schemas/ReservaInput'
 * responses:
 * '201':
 * description: Reserva creada exitosamente.
 * content:
 * application/json:
 * schema:
 * $ref: '#/components/schemas/Reserva'
 */
router.post('/', createReserva);

// --- GET (Por ID) ---
/**
 * @swagger
 * /{id}:
 * get:
 * summary: Obtiene una reserva por su ID
 * description: Retorna los detalles de una reserva específica.
 * tags: [Reservas]
 * parameters:
 * - in: path
 * name: id
 * required: true
 * schema:
 * type: string
 * description: El ID de la reserva a buscar.
 * responses:
 * '200':
 * description: Detalles de la reserva.
 * content:
 * application/json:
 * schema:
 * $ref: '#/components/schemas/Reserva'
 * '404':
 * description: Reserva no encontrada.
 */
router.get('/:id', getReservaById);

// --- PUT (Actualizar) ---
/**
 * @swagger
 * /{id}:
 * put:
 * summary: Actualiza una reserva existente
 * description: Actualiza los datos de una reserva por su ID.
 * tags: [Reservas]
 * parameters:
 * - in: path
 * name: id
 * required: true
 * schema:
 * type: string
 * description: El ID de la reserva a actualizar.
 * requestBody:
 * required: true
 * description: Datos nuevos para la reserva.
 * content:
 * application/json:
 * schema:
 * $ref: '#/components/schemas/ReservaInput'
 * responses:
 * '200':
 * description: Reserva actualizada exitosamente.
 * content:
 * application/json:
 * schema:
 * $ref: '#/components/schemas/Reserva'
 * '404':
 * description: Reserva no encontrada.
 */
router.put('/:id', updateReserva); 

// --- DELETE (Borrar) ---
/**
 * @swagger
 * /{id}:
 * delete:
 * summary: Elimina una reserva
 * description: Elimina una reserva de la base de datos por su ID.
 * tags: [Reservas]
 * parameters:
 * - in: path
 * name: id
 * required: true
 * schema:
 * type: string
 * description: El ID de la reserva a eliminar.
 * responses:
 * '204':
 * description: Reserva eliminada exitosamente (Sin contenido).
 * '404':
 * description: Reserva no encontrada.
 */
router.delete('/:id', deleteReserva);

module.exports = router;