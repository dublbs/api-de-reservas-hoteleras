// 1. Importar las librerías
const express = require('express');
const dotenv = require('dotenv');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');
const path = require('path'); // <--- El módulo 'path'

// 2. Cargar las variables de entorno
dotenv.config();

// 3. Crear la instancia de Express
const app = express();

// 4. Definir el puerto
const PORT = process.env.PORT || 4000;

// 5. Middlewares
app.use(express.json());

// 6. Configurar las rutas principales
app.use('/api/reservas', require('./routes/reservas.routes'));

// 7. ---- CONFIGURACIÓN DE SWAGGER ----
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API de Reservas de Hoteles',
      version: '1.0.0',
    },
    servers: [
      {
        url: `http://localhost:${PORT}`,
      },
    ],
  },
  // ¡LA LÍNEA MODIFICADA! Usamos un path absoluto
  apis: [path.join(__dirname, './routes/*.js')], 
};

const specs = swaggerJsdoc(options);
app.use(
  '/api-docs',
  swaggerUi.serve,
  swaggerUi.setup(specs)
);
// ---- FIN DE LA CONFIGURACIÓN DE SWAGGER ----

// 8. Levantar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
  console.log(`Documentación de Swagger disponible en http://localhost:${PORT}/api-docs`);
});