// 1. "Base de datos" en memoria
let db_reservas = [
  {
    "id": "1",
    "hotel": "Hotel Paraíso",
    "fecha_inicio": "2023-12-20",
    "fecha_fin": "2023-12-25",
    "tipo_habitacion": "suite",
    "num_huespedes": 2,
    "estado": "pendiente"
  },
  {
    "id": "2",
    "hotel": "Hotel Olas",
    "fecha_inicio": "2024-01-10",
    "fecha_fin": "2024-01-12",
    "tipo_habitacion": "doble",
    "num_huespedes": 2,
    "estado": "pendiente"
  }
];

// 2. Función OBTENER TODAS (GET) - AHORA CON TODOS LOS FILTROS
const getAllReservas = (req, res) => {
  // 1. Empezamos con la lista completa de reservas
  // Es importante copiar el array para no modificar el original
  let resultados = [...db_reservas];

  // 2. Extraemos todos los posibles 'query params' de la URL
  const { 
    hotel, 
    fecha_inicio, 
    fecha_fin, 
    tipo_habitacion, 
    estado, 
    num_huespedes 
  } = req.query;

  // 3. Aplicamos los filtros UNO POR UNO, si es que existen
  
  // Filtro por hotel
  if (hotel) {
    resultados = resultados.filter(reserva => 
      reserva.hotel.toLowerCase() === hotel.toLowerCase()
    );
  }

  // Filtro por tipo de habitación
  if (tipo_habitacion) {
    resultados = resultados.filter(reserva => 
      reserva.tipo_habitacion.toLowerCase() === tipo_habitacion.toLowerCase()
    );
  }

  // Filtro por estado
  if (estado) {
    resultados = resultados.filter(reserva => 
      reserva.estado.toLowerCase() === estado.toLowerCase()
    );
  }

  // Filtro por número de huéspedes (queremos que sea >= al número)
  if (num_huespedes) {
    const num = parseInt(num_huespedes, 10);
    resultados = resultados.filter(reserva => 
      reserva.num_huespedes >= num
    );
  }

  // Filtro por rango de fechas (el más complejo)
  // Buscamos reservas que se "solapen" (chocan) con el rango
  if (fecha_inicio && fecha_fin) {
    const inicioFiltro = new Date(fecha_inicio);
    const finFiltro = new Date(fecha_fin);

    resultados = resultados.filter(reserva => {
      const inicioReserva = new Date(reserva.fecha_inicio);
      const finReserva = new Date(reserva.fecha_fin);

      // La lógica de solapamiento es:
      // El inicio de la reserva es ANTES de que termine el filtro
      // Y el fin de la reserva es DESPUÉS de que empiece el filtro
      return inicioReserva <= finFiltro && finReserva >= inicioFiltro;
    });
  }

  // 4. Devolvemos el resultado final
  res.status(200).json(resultados);
};

// 3. Función OBTENER UNA POR ID (GET /:id)
const getReservaById = (req, res) => {
  const idBuscado = req.params.id;
  const reserva = db_reservas.find(reserva => reserva.id === idBuscado);

  if (reserva) {
    res.status(200).json(reserva);
  } else {
    res.status(404).json({ message: `No se encontró la reserva con id ${idBuscado}` });
  }
};

// 4. Función CREAR una reserva (POST)
const createReserva = (req, res) => {
  const nuevaReserva = req.body;
  const nuevoId = String(db_reservas.length + 1); 
  const reservaAGuardar = {
    id: nuevoId,
    ...nuevaReserva 
  };
  db_reservas.push(reservaAGuardar);
  res.status(201).json(reservaAGuardar);
};

// 5. Función ACTUALIZAR una reserva (PUT /:id)
const updateReserva = (req, res) => {
  const idBuscado = req.params.id;
  const index = db_reservas.findIndex(reserva => reserva.id === idBuscado);

  if (index !== -1) {
    const datosNuevos = req.body;
    db_reservas[index] = { ...db_reservas[index], ...datosNuevos };
    res.status(200).json(db_reservas[index]);
  } else {
    res.status(404).json({ message: `No se encontró la reserva con id ${idBuscado}` });
  }
};

// 6. Función para BORRAR una reserva (DELETE /:id)
const deleteReserva = (req, res) => {
  // 1. Obtener el ID
  const idBuscado = req.params.id;

  // 2. Encontrar el índice
  const index = db_reservas.findIndex(reserva => reserva.id === idBuscado);

  // 3. Comprobar si existe
  if (index !== -1) {
    // 4. Eliminar la reserva del array
    db_reservas.splice(index, 1);
    
    // 5. Responder con 204 (No Content), es el estándar para un DELETE exitoso
    res.status(204).send();
  } else {
    // Si no, devolvemos un error 404 (No Encontrado)
    res.status(404).json({ message: `No se encontró la reserva con id ${idBuscado}` });
  }
};


// 7. EXPORTACIONES 
module.exports = {
  getAllReservas,
  getReservaById,
  createReserva,
  updateReserva,
  deleteReserva 
};